var dir_3e0d2c868be6a3e5150a628fd2a00a9b =
[
    [ "aajw_header.cpp", "aajw__header_8cpp.html", null ],
    [ "aajw_header.h", "aajw__header_8h.html", [
      [ "AHdr", "class_a_hdr.html", "class_a_hdr" ],
      [ "AAJWHEADER", "struct_a_hdr_1_1_a_a_j_w_h_e_a_d_e_r.html", "struct_a_hdr_1_1_a_a_j_w_h_e_a_d_e_r" ]
    ] ],
    [ "byterun_c.cpp", "byterun__c_8cpp.html", null ],
    [ "byterun_c.h", "byterun__c_8h.html", [
      [ "ByteRun_c", "class_byte_run__c.html", "class_byte_run__c" ]
    ] ],
    [ "imgbaseinfo.cpp", "imgbaseinfo_8cpp.html", null ],
    [ "imgbaseinfo.h", "imgbaseinfo_8h.html", [
      [ "ImgBaseInfo", "class_img_base_info.html", "class_img_base_info" ],
      [ "unsigned_pair", "struct_img_base_info_1_1unsigned__pair.html", "struct_img_base_info_1_1unsigned__pair" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mainwindow.cpp", "mainwindow_8cpp.html", null ],
    [ "mainwindow.h", "mainwindow_8h.html", [
      [ "MainWindow", "class_main_window.html", "class_main_window" ],
      [ "unsigned_pair", "struct_main_window_1_1unsigned__pair.html", "struct_main_window_1_1unsigned__pair" ]
    ] ],
    [ "RLE_c.cpp", "_r_l_e__c_8cpp.html", null ],
    [ "rle_c.h", "rle__c_8h.html", [
      [ "RLE_c", "class_r_l_e__c.html", "class_r_l_e__c" ]
    ] ],
    [ "scale.cpp", "scale_8cpp.html", null ],
    [ "scale.h", "scale_8h.html", [
      [ "Scale", "class_scale.html", "class_scale" ]
    ] ],
    [ "serialize.cpp", "serialize_8cpp.html", null ],
    [ "serialize.h", "serialize_8h.html", [
      [ "Serialize", "class_serialize.html", "class_serialize" ]
    ] ],
    [ "sevenbitcomp.cpp", "sevenbitcomp_8cpp.html", null ],
    [ "sevenbitcomp.h", "sevenbitcomp_8h.html", [
      [ "SevenBitComp", "class_seven_bit_comp.html", "class_seven_bit_comp" ]
    ] ],
    [ "SevenBitComp_old.cpp", "_seven_bit_comp__old_8cpp.html", null ],
    [ "SevenBitComp_old.h", "_seven_bit_comp__old_8h.html", [
      [ "SevenBitComp", "class_seven_bit_comp.html", "class_seven_bit_comp" ]
    ] ],
    [ "sfml_objects.cpp", "sfml__objects_8cpp.html", null ],
    [ "sfml_objects.h", "sfml__objects_8h.html", [
      [ "SFML_Objects", "class_s_f_m_l___objects.html", "class_s_f_m_l___objects" ]
    ] ],
    [ "vec_bmp.cpp", "vec__bmp_8cpp.html", null ],
    [ "vec_bmp.h", "vec__bmp_8h.html", "vec__bmp_8h" ],
    [ "vec_extr.cpp", "vec__extr_8cpp.html", null ],
    [ "vec_extr.h", "vec__extr_8h.html", [
      [ "Vec_Extr", "class_vec___extr.html", "class_vec___extr" ]
    ] ]
];