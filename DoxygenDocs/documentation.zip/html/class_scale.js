var class_scale =
[
    [ "mode", "class_scale.html#a53f5b0bcb725666bd9642dafbd499d88", [
      [ "keep_ratio", "class_scale.html#a53f5b0bcb725666bd9642dafbd499d88a17d573f46491f4e1aa0fc8dfa8a7e9f0", null ],
      [ "fit_to_screen", "class_scale.html#a53f5b0bcb725666bd9642dafbd499d88a03de4feabec30f277fe04c35c9dcf96c", null ],
      [ "stretch_and_keep_ratio", "class_scale.html#a53f5b0bcb725666bd9642dafbd499d88a4e1c06fec7ed2b2e0616b5301057e861", null ],
      [ "stretch_to_fit", "class_scale.html#a53f5b0bcb725666bd9642dafbd499d88ac98eff4ab79a09d8626607b883660f2a", null ]
    ] ],
    [ "Scale", "class_scale.html#a3cbac3c69ff5a4593dc95168e1656b8d", null ],
    [ "Scale", "class_scale.html#a58b947ec64cd04e67180ea15766b6855", null ],
    [ "~Scale", "class_scale.html#a9f13d7998aac5e015155c12d0d109010", null ],
    [ "adjust", "class_scale.html#add8bb17d093c13488d20b8fd489f1af9", null ],
    [ "adjust", "class_scale.html#a21af255970d236ac7a7bb0b82e2f5cac", null ],
    [ "calculate", "class_scale.html#ac9f225ada475d632aa0c6244d01a28ba", null ],
    [ "getPosX", "class_scale.html#aedf26dcafb7ce3db93b8d47d335f32f5", null ],
    [ "getPosY", "class_scale.html#a8bb8dc0c784db1d9aae14231ca78b4ea", null ],
    [ "getXScale", "class_scale.html#aa2232ec814fd7de43a98ceba65968445", null ],
    [ "getYScale", "class_scale.html#a26b17bb7232cf0399529cc2f18b6d877", null ],
    [ "setframeX", "class_scale.html#aa4eb8e673ddf19c8744d26653fbc5e8e", null ],
    [ "setframeY", "class_scale.html#aab1ee23f1184fb0d26b16d1a5e7f74a8", null ],
    [ "setMode", "class_scale.html#aed66fdf5dfdeb44706bb33370cb0ca70", null ],
    [ "setPosition", "class_scale.html#aa11bd537b9084a8494167d04b06b84ea", null ],
    [ "setX", "class_scale.html#a912b1bde965d8a28a12098b1677e5251", null ],
    [ "setY", "class_scale.html#adc583727d1503ff1350245fdf6ff5d9b", null ],
    [ "flag_t", "class_scale.html#aea5b7222d36ff4b0cb5d7edd2e8dcf52", null ],
    [ "img_x", "class_scale.html#a1085d7916e4fcf7d84c61cf68b060c8e", null ],
    [ "img_y", "class_scale.html#a357a8c1b1b1c30d09fd04c3ff7005564", null ],
    [ "pos_x", "class_scale.html#ae04c59381f7046cdcc795035f78b700d", null ],
    [ "pos_y", "class_scale.html#aa5c849357873b2149b7ff43dc81c2746", null ],
    [ "win_x", "class_scale.html#a3b2febdfca846149af0af34e9f2bf158", null ],
    [ "win_y", "class_scale.html#a0f4954ba5da80fd08562cef6209bf8cb", null ],
    [ "XScale", "class_scale.html#aa27b164b0db80b0735b0c32ec26ae123", null ],
    [ "YScale", "class_scale.html#a54830d48e669d956c438e0654aa96ba0", null ]
];