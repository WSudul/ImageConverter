var searchData=
[
  ['grey',['grey',['../class_a_hdr.html#a7905be4154d0d5ccdbd7b4e0e4a59383aca50000a180a293de0b27acb67a695cb',1,'AHdr::grey()'],['../class_img_base_info.html#aaa5a8dd42852cab6b08cadda321b4efea32c4d60027e02ab755d530fb71c3d310',1,'ImgBaseInfo::GREY()']]],
  ['greyscale',['GREYSCALE',['../class_vec___extr.html#a8d7151eccfe7802f8a7ee13858efd092a68577b71e3dd6736f90f7726368600a0',1,'Vec_Extr']]],
  ['greyscale_5favg',['GREYSCALE_AVG',['../class_vec___extr.html#a8d7151eccfe7802f8a7ee13858efd092a4bae3663163819d5196b3201217486f6',1,'Vec_Extr']]]
];
