var searchData=
[
  ['color_5fmode',['color_mode',['../class_vec___extr.html#a8d7151eccfe7802f8a7ee13858efd092',1,'Vec_Extr']]]
];
