var searchData=
[
  ['win_5fx',['win_x',['../class_scale.html#a3b2febdfca846149af0af34e9f2bf158',1,'Scale']]],
  ['win_5fy',['win_y',['../class_scale.html#a0f4954ba5da80fd08562cef6209bf8cb',1,'Scale']]]
];
