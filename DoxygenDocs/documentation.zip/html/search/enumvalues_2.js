var searchData=
[
  ['fit_5fto_5fscreen',['fit_to_screen',['../class_scale.html#a53f5b0bcb725666bd9642dafbd499d88a03de4feabec30f277fe04c35c9dcf96c',1,'Scale']]]
];
