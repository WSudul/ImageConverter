var searchData=
[
  ['long',['LONG',['../vec__bmp_8h.html#acaa7b8a7167a8214f499c71c413ddcca',1,'vec_bmp.h']]]
];
