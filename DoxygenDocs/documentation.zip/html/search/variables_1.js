var searchData=
[
  ['colors',['colors',['../class_img_base_info.html#a1182284a4ad32d838cd9f090bd61baed',1,'ImgBaseInfo']]],
  ['comp_5fgroup',['comp_group',['../class_main_window.html#a4418813a6a1baaca94bbb109d2ff6088',1,'MainWindow']]],
  ['compr_5fbuttons',['Compr_Buttons',['../class_main_window.html#a0bdb57499279fbed6fc0bdda15c7eaa1',1,'MainWindow']]],
  ['compresseddata',['compressedData',['../class_seven_bit_comp.html#a8119c8bd361a8880d7ffed5fdc291322',1,'SevenBitComp']]],
  ['compression',['compression',['../class_img_base_info.html#a29acac1f0a5e2003cf15bda6c5f8ed2f',1,'ImgBaseInfo']]]
];
