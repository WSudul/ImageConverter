var searchData=
[
  ['lossy',['lossy',['../class_a_hdr.html#a01dcb9a5d7873d6808645afe873b5227a2645226e2ce8d79a577b5e8136141ca6',1,'AHdr']]]
];
