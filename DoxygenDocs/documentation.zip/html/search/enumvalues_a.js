var searchData=
[
  ['stretch_5fand_5fkeep_5fratio',['stretch_and_keep_ratio',['../class_scale.html#a53f5b0bcb725666bd9642dafbd499d88a4e1c06fec7ed2b2e0616b5301057e861',1,'Scale']]],
  ['stretch_5fto_5ffit',['stretch_to_fit',['../class_scale.html#a53f5b0bcb725666bd9642dafbd499d88ac98eff4ab79a09d8626607b883660f2a',1,'Scale']]]
];
