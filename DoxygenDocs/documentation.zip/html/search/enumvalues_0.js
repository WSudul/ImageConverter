var searchData=
[
  ['b_5fw',['b_w',['../class_a_hdr.html#a7905be4154d0d5ccdbd7b4e0e4a59383a73a128f1fb102f2c510a69c64d275ddf',1,'AHdr::b_w()'],['../class_vec___extr.html#a8d7151eccfe7802f8a7ee13858efd092aa6098321da8717e3aee5484162bf5ed4',1,'Vec_Extr::B_W()']]],
  ['black_5fwhite',['BLACK_WHITE',['../class_img_base_info.html#aaa5a8dd42852cab6b08cadda321b4efead8ee1e4175c1746c79c57f4c39bfa136',1,'ImgBaseInfo']]],
  ['byterun',['byterun',['../class_a_hdr.html#acfacae70f76a15f200eaafb7e4149ea7affd951648f806ddbee00f8541c4a07df',1,'AHdr']]],
  ['byterun3',['byterun3',['../class_a_hdr.html#acfacae70f76a15f200eaafb7e4149ea7a59c053e1a1d4ca6b23a3123c46f20e4f',1,'AHdr']]]
];
