var searchData=
[
  ['viewer',['Viewer',['../class_main_window.html#a16bc4a163b5c65a279acd429cca6262a',1,'MainWindow']]],
  ['viewer_5fdef_5fsize',['Viewer_def_size',['../class_main_window.html#a5d867c2e588485f232c5548cfa9aaf1a',1,'MainWindow']]]
];
