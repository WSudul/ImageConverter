var searchData=
[
  ['x',['x',['../struct_img_base_info_1_1unsigned__pair.html#a35410bb8b3befefd9036ea8bcfa2c6bf',1,'ImgBaseInfo::unsigned_pair::x()'],['../struct_main_window_1_1unsigned__pair.html#ac040b111fc19192daf8e0b0d2e55cba9',1,'MainWindow::unsigned_pair::x()']]],
  ['xscale',['XScale',['../class_scale.html#aa27b164b0db80b0735b0c32ec26ae123',1,'Scale']]]
];
