var searchData=
[
  ['getcolors',['getColors',['../class_img_base_info.html#a92a48754ced48bb7b87e4041124eff2f',1,'ImgBaseInfo']]],
  ['getcompression',['getCompression',['../class_img_base_info.html#aad1e32d07400ece0c3c2c5551dba9162',1,'ImgBaseInfo']]],
  ['getmodel',['getModel',['../class_img_base_info.html#ae39da3cb30bd2706594ba3aa452d33d7',1,'ImgBaseInfo']]],
  ['getpack_5ftype',['getPack_type',['../class_img_base_info.html#ae99e64f943a0cdeda6fff6b78d6459a3',1,'ImgBaseInfo']]],
  ['getposx',['getPosX',['../class_scale.html#aedf26dcafb7ce3db93b8d47d335f32f5',1,'Scale']]],
  ['getposy',['getPosY',['../class_scale.html#a8bb8dc0c784db1d9aae14231ca78b4ea',1,'Scale']]],
  ['getsize',['getSize',['../class_img_base_info.html#ad829a5bfd4a60db5bc6866972a24c9d4',1,'ImgBaseInfo']]],
  ['getxscale',['getXScale',['../class_scale.html#aa2232ec814fd7de43a98ceba65968445',1,'Scale']]],
  ['getyscale',['getYScale',['../class_scale.html#a26b17bb7232cf0399529cc2f18b6d877',1,'Scale']]],
  ['grey',['grey',['../class_a_hdr.html#a7905be4154d0d5ccdbd7b4e0e4a59383aca50000a180a293de0b27acb67a695cb',1,'AHdr::grey()'],['../class_img_base_info.html#aaa5a8dd42852cab6b08cadda321b4efea32c4d60027e02ab755d530fb71c3d310',1,'ImgBaseInfo::GREY()']]],
  ['greyscale',['GREYSCALE',['../class_vec___extr.html#a8d7151eccfe7802f8a7ee13858efd092a68577b71e3dd6736f90f7726368600a0',1,'Vec_Extr']]],
  ['greyscale_5favg',['GREYSCALE_AVG',['../class_vec___extr.html#a8d7151eccfe7802f8a7ee13858efd092a4bae3663163819d5196b3201217486f6',1,'Vec_Extr']]]
];
