var searchData=
[
  ['imgbaseinfo_2ecpp',['imgbaseinfo.cpp',['../imgbaseinfo_8cpp.html',1,'']]],
  ['imgbaseinfo_2eh',['imgbaseinfo.h',['../imgbaseinfo_8h.html',1,'']]]
];
