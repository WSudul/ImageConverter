var searchData=
[
  ['aplikacja',['Aplikacja',['../index.html',1,'']]]
];
