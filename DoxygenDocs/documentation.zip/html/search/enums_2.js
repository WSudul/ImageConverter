var searchData=
[
  ['data_5fmodel',['data_model',['../class_img_base_info.html#aaa5a8dd42852cab6b08cadda321b4efe',1,'ImgBaseInfo']]]
];
