var searchData=
[
  ['qsavetobmp',['QSaveToBMP',['../class_vec___b_m_p.html#a61e14c6159b9ca012568a853c8d4b11a',1,'Vec_BMP']]],
  ['quit_5fask',['quit_ask',['../class_main_window.html#a199e2e317182b9a50dd62e7c40c545af',1,'MainWindow']]]
];
