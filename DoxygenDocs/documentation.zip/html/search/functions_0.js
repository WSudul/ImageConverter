var searchData=
[
  ['add_5finfo_5ftext',['add_info_text',['../class_main_window.html#a9ab4bcea400c33f26f4eccf3755a8458',1,'MainWindow']]],
  ['adjust',['adjust',['../class_scale.html#add8bb17d093c13488d20b8fd489f1af9',1,'Scale::adjust(unsigned int x, unsigned int y, bool center=true, mode arg=keep_ratio)'],['../class_scale.html#a21af255970d236ac7a7bb0b82e2f5cac',1,'Scale::adjust(bool center=true)']]],
  ['ahdr',['AHdr',['../class_a_hdr.html#ae0e5c1931a8e406dec80ad482a0fc876',1,'AHdr']]]
];
