var searchData=
[
  ['image',['Image',['../class_s_f_m_l___objects.html#a96e8da8c7a8152e2ee52afbef2204b22',1,'SFML_Objects']]],
  ['img_5fx',['img_x',['../class_scale.html#a1085d7916e4fcf7d84c61cf68b060c8e',1,'Scale']]],
  ['img_5fy',['img_y',['../class_scale.html#a357a8c1b1b1c30d09fd04c3ff7005564',1,'Scale']]]
];
