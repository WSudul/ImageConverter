var searchData=
[
  ['img_5fextract',['img_extract',['../class_vec___extr.html#a43e84d2878b1699d9016521b65e9f520',1,'Vec_Extr::img_extract(sf::Image &amp;image, ImgBaseInfo &amp;info, color_mode flag=color_mode::RGB)'],['../class_vec___extr.html#ad794de22e48f50b897a3f238cd583944',1,'Vec_Extr::img_extract(std::string name, ImgBaseInfo &amp;info, color_mode flag=color_mode::RGB)']]],
  ['int32tole',['int32toLE',['../class_serialize.html#a5c0c543d956690babfdbd841a0e2f13a',1,'Serialize']]]
];
