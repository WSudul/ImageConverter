var searchData=
[
  ['mode',['mode',['../class_scale.html#a53f5b0bcb725666bd9642dafbd499d88',1,'Scale']]]
];
