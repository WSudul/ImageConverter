var searchData=
[
  ['f7bit',['F7Bit',['../struct_a_hdr_1_1_a_a_j_w_h_e_a_d_e_r.html#a6e93e00502c01c65f0f8ce1ac20ec658',1,'AHdr::AAJWHEADER']]],
  ['fcolor',['FColor',['../struct_a_hdr_1_1_a_a_j_w_h_e_a_d_e_r.html#a14e5aedd0dc604584a3dcdc28cc96953',1,'AHdr::AAJWHEADER']]],
  ['fcompression',['FCompression',['../struct_a_hdr_1_1_a_a_j_w_h_e_a_d_e_r.html#aac95d8b273ca637de37d09365a8d7531',1,'AHdr::AAJWHEADER']]],
  ['fdatasize',['FDataSize',['../struct_a_hdr_1_1_a_a_j_w_h_e_a_d_e_r.html#a8788fcefb6cf691306449590b598a8a1',1,'AHdr::AAJWHEADER']]],
  ['fidentifier',['FIdentifier',['../struct_a_hdr_1_1_a_a_j_w_h_e_a_d_e_r.html#a66d5e7dee1661f0f9160208e7a86fec6',1,'AHdr::AAJWHEADER']]],
  ['fit_5fto_5fscreen',['fit_to_screen',['../class_scale.html#a53f5b0bcb725666bd9642dafbd499d88a03de4feabec30f277fe04c35c9dcf96c',1,'Scale']]],
  ['flag_5ft',['flag_t',['../class_scale.html#aea5b7222d36ff4b0cb5d7edd2e8dcf52',1,'Scale']]],
  ['fsizex',['FSizeX',['../struct_a_hdr_1_1_a_a_j_w_h_e_a_d_e_r.html#a4ed548bb0e52d953eda50ad44b1d62b8',1,'AHdr::AAJWHEADER']]],
  ['fsizey',['FSizeY',['../struct_a_hdr_1_1_a_a_j_w_h_e_a_d_e_r.html#ab5e34a0b2fc4be0287b8934d5d0515a7',1,'AHdr::AAJWHEADER']]]
];
