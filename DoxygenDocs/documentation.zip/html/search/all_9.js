var searchData=
[
  ['keep_5fratio',['keep_ratio',['../class_scale.html#a53f5b0bcb725666bd9642dafbd499d88a17d573f46491f4e1aa0fc8dfa8a7e9f0',1,'Scale']]]
];
