var searchData=
[
  ['a_5fbi_5fbitfields',['A_BI_BITFIELDS',['../vec__bmp_8h.html#a28ae3bee9f80655030dbdbd88e98b818',1,'vec_bmp.h']]],
  ['a_5fbi_5fjpeg',['A_BI_JPEG',['../vec__bmp_8h.html#a262c0461133a184be7f26cf480f941b9',1,'vec_bmp.h']]],
  ['a_5fbi_5fpng',['A_BI_PNG',['../vec__bmp_8h.html#a4face990533894ea60ff5126c599f481',1,'vec_bmp.h']]],
  ['a_5fbi_5frgb',['A_BI_RGB',['../vec__bmp_8h.html#a24499130317221694a37e7638de7f4ca',1,'vec_bmp.h']]],
  ['a_5fbi_5frle4',['A_BI_RLE4',['../vec__bmp_8h.html#a9904a9fa96212e67f1f741b03c88f40c',1,'vec_bmp.h']]],
  ['a_5fbi_5frle8',['A_BI_RLE8',['../vec__bmp_8h.html#ab132c39b0430ac603cf9146dd106c4ba',1,'vec_bmp.h']]],
  ['aajw7bit',['AAJW7bit',['../class_a_hdr.html#a01dcb9a5d7873d6808645afe873b5227',1,'AHdr']]],
  ['aajw_5fheader_2ecpp',['aajw_header.cpp',['../aajw__header_8cpp.html',1,'']]],
  ['aajw_5fheader_2eh',['aajw_header.h',['../aajw__header_8h.html',1,'']]],
  ['aajwcompression',['AAJWCompression',['../class_a_hdr.html#acfacae70f76a15f200eaafb7e4149ea7',1,'AHdr']]],
  ['aajwheader',['AAJWHEADER',['../struct_a_hdr_1_1_a_a_j_w_h_e_a_d_e_r.html',1,'AHdr']]],
  ['acolor',['AColor',['../class_a_hdr.html#a7905be4154d0d5ccdbd7b4e0e4a59383',1,'AHdr']]],
  ['add_5finfo_5ftext',['add_info_text',['../class_main_window.html#a9ab4bcea400c33f26f4eccf3755a8458',1,'MainWindow']]],
  ['adjust',['adjust',['../class_scale.html#add8bb17d093c13488d20b8fd489f1af9',1,'Scale::adjust(unsigned int x, unsigned int y, bool center=true, mode arg=keep_ratio)'],['../class_scale.html#a21af255970d236ac7a7bb0b82e2f5cac',1,'Scale::adjust(bool center=true)']]],
  ['ahdr',['AHdr',['../class_a_hdr.html',1,'AHdr'],['../class_a_hdr.html#ae0e5c1931a8e406dec80ad482a0fc876',1,'AHdr::AHdr()']]],
  ['aplikacja',['Aplikacja',['../index.html',1,'']]]
];
