var searchData=
[
  ['unsigned_5fpair',['unsigned_pair',['../struct_main_window_1_1unsigned__pair.html',1,'MainWindow']]],
  ['unsigned_5fpair',['unsigned_pair',['../struct_img_base_info_1_1unsigned__pair.html',1,'ImgBaseInfo']]]
];
