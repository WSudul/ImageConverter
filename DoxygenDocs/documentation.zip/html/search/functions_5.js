var searchData=
[
  ['getcolors',['getColors',['../class_img_base_info.html#a92a48754ced48bb7b87e4041124eff2f',1,'ImgBaseInfo']]],
  ['getcompression',['getCompression',['../class_img_base_info.html#aad1e32d07400ece0c3c2c5551dba9162',1,'ImgBaseInfo']]],
  ['getmodel',['getModel',['../class_img_base_info.html#ae39da3cb30bd2706594ba3aa452d33d7',1,'ImgBaseInfo']]],
  ['getpack_5ftype',['getPack_type',['../class_img_base_info.html#ae99e64f943a0cdeda6fff6b78d6459a3',1,'ImgBaseInfo']]],
  ['getposx',['getPosX',['../class_scale.html#aedf26dcafb7ce3db93b8d47d335f32f5',1,'Scale']]],
  ['getposy',['getPosY',['../class_scale.html#a8bb8dc0c784db1d9aae14231ca78b4ea',1,'Scale']]],
  ['getsize',['getSize',['../class_img_base_info.html#ad829a5bfd4a60db5bc6866972a24c9d4',1,'ImgBaseInfo']]],
  ['getxscale',['getXScale',['../class_scale.html#aa2232ec814fd7de43a98ceba65968445',1,'Scale']]],
  ['getyscale',['getYScale',['../class_scale.html#a26b17bb7232cf0399529cc2f18b6d877',1,'Scale']]]
];
