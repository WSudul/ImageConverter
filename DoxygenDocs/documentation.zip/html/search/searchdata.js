var indexSectionsWithContent =
{
  0: "abcdefghiklmnopqrstuvwxy~",
  1: "abimrsuv",
  2: "u",
  3: "abimrsv",
  4: "abcdegilmopqrsuv~",
  5: "bcefilmprstuvwxy",
  6: "acdm",
  7: "bcfghiklnrsu",
  8: "o",
  9: "abdlw",
  10: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "defines",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Klasy",
  2: "Przestrzenie nazw",
  3: "Pliki",
  4: "Funkcje",
  5: "Zmienne",
  6: "Wyliczenia",
  7: "Wartości wyliczeń",
  8: "Przyjaciele",
  9: "Definicje",
  10: "Strony"
};

