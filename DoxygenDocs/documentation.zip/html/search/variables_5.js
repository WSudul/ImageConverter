var searchData=
[
  ['logo',['logo',['../class_main_window.html#a2d58eb6ef0df268b0deda7b7c3bc47cc',1,'MainWindow']]],
  ['logo_5ferror',['logo_error',['../class_main_window.html#adff5f1b9a338c51c56487d2fbb0fca7c',1,'MainWindow']]]
];
