var searchData=
[
  ['size',['size',['../class_img_base_info.html#ae30455eb1bac8b58151d3ef81c78683b',1,'ImgBaseInfo']]],
  ['sprite',['Sprite',['../class_s_f_m_l___objects.html#a23e4c369cdcbd28b47799338c2d05836',1,'SFML_Objects']]]
];
