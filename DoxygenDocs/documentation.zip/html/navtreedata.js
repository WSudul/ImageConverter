var NAVTREE =
[
  [ "GKiM", "index.html", [
    [ "Aplikacja", "index.html", [
      [ "Wstep", "index.html#sec1", null ],
      [ "Wymagania", "index.html#sec2", [
        [ "Biblioteki", "index.html#Biblioteki", null ],
        [ "Sprzetowe", "index.html#Sprzetowe", null ]
      ] ],
      [ "Pliki naglowkowe", "index.html#sec3", null ],
      [ "Format pliku .aajw - Opis formatu AAJW", "index.html#sec4", null ],
      [ "AAJWHEADER", "index.html#Header", [
        [ "FIdentifier", "index.html#FIdentifier", null ],
        [ "FSizeY", "index.html#FSizeY", null ],
        [ "FSizeX", "index.html#FSizeX", null ],
        [ "FColor", "index.html#FColor", null ],
        [ "FDataSize", "index.html#FDataSize", null ],
        [ "FCompression", "index.html#FCompression", null ],
        [ "F7Bit", "index.html#F7Bit", null ]
      ] ],
      [ "Forma zapisu i odczytu", "index.html#secencode", null ],
      [ "Cechy formatu AAJW", "index.html#secchars", null ],
      [ "Autorzy", "index.html#sec5", null ],
      [ "Licencja", "index.html#sec6", null ]
    ] ],
    [ "Przestrzenie nazw", null, [
      [ "Lista przestrzeni nazw", "namespaces.html", "namespaces" ]
    ] ],
    [ "Klasy", "annotated.html", [
      [ "Lista klas", "annotated.html", "annotated_dup" ],
      [ "Indeks klas", "classes.html", null ],
      [ "Hierarchia klas", "hierarchy.html", "hierarchy" ],
      [ "Składowe klas", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Funkcje", "functions_func.html", null ],
        [ "Zmienne", "functions_vars.html", null ],
        [ "Wyliczenia", "functions_enum.html", null ],
        [ "Wartości wyliczeń", "functions_eval.html", null ],
        [ "Funkcje powiązane", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Pliki", null, [
      [ "Lista plików", "files.html", "files" ],
      [ "Składowe plików", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Funkcje", "globals_func.html", null ],
        [ "Definicje", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_r_l_e__c_8cpp.html",
"serialize_8h.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';