var class_img_base_info =
[
    [ "unsigned_pair", "struct_img_base_info_1_1unsigned__pair.html", "struct_img_base_info_1_1unsigned__pair" ],
    [ "data_model", "class_img_base_info.html#aaa5a8dd42852cab6b08cadda321b4efe", [
      [ "RGBA", "class_img_base_info.html#aaa5a8dd42852cab6b08cadda321b4efea4bde2d5096a7a244eb9a1fda3f1f0be7", null ],
      [ "RGB", "class_img_base_info.html#aaa5a8dd42852cab6b08cadda321b4efea07bea88b8aa326b91a0c02957c2d98df", null ],
      [ "GREY", "class_img_base_info.html#aaa5a8dd42852cab6b08cadda321b4efea32c4d60027e02ab755d530fb71c3d310", null ],
      [ "BLACK_WHITE", "class_img_base_info.html#aaa5a8dd42852cab6b08cadda321b4efead8ee1e4175c1746c79c57f4c39bfa136", null ],
      [ "HSV", "class_img_base_info.html#aaa5a8dd42852cab6b08cadda321b4efea4c7a5e4ac5861e904704ff1730525172", null ],
      [ "CMY", "class_img_base_info.html#aaa5a8dd42852cab6b08cadda321b4efea155424e40159c1a16bf44ab43ef8fa0e", null ],
      [ "CMYK", "class_img_base_info.html#aaa5a8dd42852cab6b08cadda321b4efeabe33102e2122545a297ab1e557cbd8db", null ]
    ] ],
    [ "getColors", "class_img_base_info.html#a92a48754ced48bb7b87e4041124eff2f", null ],
    [ "getCompression", "class_img_base_info.html#aad1e32d07400ece0c3c2c5551dba9162", null ],
    [ "getModel", "class_img_base_info.html#ae39da3cb30bd2706594ba3aa452d33d7", null ],
    [ "getPack_type", "class_img_base_info.html#ae99e64f943a0cdeda6fff6b78d6459a3", null ],
    [ "getSize", "class_img_base_info.html#ad829a5bfd4a60db5bc6866972a24c9d4", null ],
    [ "set_header_color_data", "class_img_base_info.html#a73f2f72f82b40715918e3a2c18757ecb", null ],
    [ "setColors", "class_img_base_info.html#acbcef290019c9da649af72f0b7a2be87", null ],
    [ "setCompression", "class_img_base_info.html#a5b06bd1adec9c7ccbec67f72b44160cf", null ],
    [ "setModel", "class_img_base_info.html#a9f9ae11deb856b28c82afafd7e98d508", null ],
    [ "setPack_type", "class_img_base_info.html#aaffaf375f2c9a801d8a5aa499c8c6cb6", null ],
    [ "setSize", "class_img_base_info.html#ae2b01db90a6d22a380b27905879b51ff", null ],
    [ "colors", "class_img_base_info.html#a1182284a4ad32d838cd9f090bd61baed", null ],
    [ "compression", "class_img_base_info.html#a29acac1f0a5e2003cf15bda6c5f8ed2f", null ],
    [ "model", "class_img_base_info.html#aa31de9bba4d16d02df19fa137d5b0d93", null ],
    [ "pack_type", "class_img_base_info.html#af8e1b9a22205c199edc416520e3ffd2b", null ],
    [ "size", "class_img_base_info.html#ae30455eb1bac8b58151d3ef81c78683b", null ]
];