var struct_vec___b_m_p_1_1_b_i_t_m_a_p_i_n_f_o_h_e_a_d_e_r =
[
    [ "biBitCount", "struct_vec___b_m_p_1_1_b_i_t_m_a_p_i_n_f_o_h_e_a_d_e_r.html#ae8ec5d5f42cf5ac53c376f8db2878663", null ],
    [ "biClrImportant", "struct_vec___b_m_p_1_1_b_i_t_m_a_p_i_n_f_o_h_e_a_d_e_r.html#a58d020773e97b180ac7128f3919641fe", null ],
    [ "biClrUsed", "struct_vec___b_m_p_1_1_b_i_t_m_a_p_i_n_f_o_h_e_a_d_e_r.html#a17cfd78e2f3097fb76ef87d5b767df60", null ],
    [ "biCompression", "struct_vec___b_m_p_1_1_b_i_t_m_a_p_i_n_f_o_h_e_a_d_e_r.html#a84500044ca5bd0295dc0a393e16083f6", null ],
    [ "biHeight", "struct_vec___b_m_p_1_1_b_i_t_m_a_p_i_n_f_o_h_e_a_d_e_r.html#a59f910beda5a9c78fb978bb3ce6ec943", null ],
    [ "biPlanes", "struct_vec___b_m_p_1_1_b_i_t_m_a_p_i_n_f_o_h_e_a_d_e_r.html#a9e60d65a0f4d7a64080cf2d5d1187e47", null ],
    [ "biSize", "struct_vec___b_m_p_1_1_b_i_t_m_a_p_i_n_f_o_h_e_a_d_e_r.html#a083afcf0f11418c8e20415aaa69d9700", null ],
    [ "biSizeImage", "struct_vec___b_m_p_1_1_b_i_t_m_a_p_i_n_f_o_h_e_a_d_e_r.html#ade28b0d30b743d37debdbb83450bd634", null ],
    [ "biWidth", "struct_vec___b_m_p_1_1_b_i_t_m_a_p_i_n_f_o_h_e_a_d_e_r.html#a66229c3d6555b90b0bf6342c98643da8", null ],
    [ "biXPelsPerMeter", "struct_vec___b_m_p_1_1_b_i_t_m_a_p_i_n_f_o_h_e_a_d_e_r.html#a351196d204c02c8cea08919094d7c0a8", null ],
    [ "biYPelsPerMeter", "struct_vec___b_m_p_1_1_b_i_t_m_a_p_i_n_f_o_h_e_a_d_e_r.html#a103345dad74a427ab785b456e198d578", null ]
];