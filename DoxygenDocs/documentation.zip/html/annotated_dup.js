var annotated_dup =
[
    [ "AHdr", "class_a_hdr.html", "class_a_hdr" ],
    [ "ByteRun_c", "class_byte_run__c.html", "class_byte_run__c" ],
    [ "ImgBaseInfo", "class_img_base_info.html", "class_img_base_info" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "RLE_c", "class_r_l_e__c.html", "class_r_l_e__c" ],
    [ "Scale", "class_scale.html", "class_scale" ],
    [ "Serialize", "class_serialize.html", "class_serialize" ],
    [ "SevenBitComp", "class_seven_bit_comp.html", "class_seven_bit_comp" ],
    [ "SFML_Objects", "class_s_f_m_l___objects.html", "class_s_f_m_l___objects" ],
    [ "Vec_BMP", "class_vec___b_m_p.html", "class_vec___b_m_p" ],
    [ "Vec_Extr", "class_vec___extr.html", "class_vec___extr" ]
];