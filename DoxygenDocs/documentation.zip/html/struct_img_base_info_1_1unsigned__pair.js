var struct_img_base_info_1_1unsigned__pair =
[
    [ "x", "struct_img_base_info_1_1unsigned__pair.html#a35410bb8b3befefd9036ea8bcfa2c6bf", null ],
    [ "y", "struct_img_base_info_1_1unsigned__pair.html#ad0d3aab09cf12fc9472c04bd1843ea87", null ]
];