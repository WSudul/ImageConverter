var class_a_hdr =
[
    [ "AAJWHEADER", "struct_a_hdr_1_1_a_a_j_w_h_e_a_d_e_r.html", "struct_a_hdr_1_1_a_a_j_w_h_e_a_d_e_r" ],
    [ "AAJW7bit", "class_a_hdr.html#a01dcb9a5d7873d6808645afe873b5227", [
      [ "lossy", "class_a_hdr.html#a01dcb9a5d7873d6808645afe873b5227a2645226e2ce8d79a577b5e8136141ca6", null ],
      [ "unpacked", "class_a_hdr.html#a01dcb9a5d7873d6808645afe873b5227a78a068b187a564f21b93e72acffcebc3", null ]
    ] ],
    [ "AAJWCompression", "class_a_hdr.html#acfacae70f76a15f200eaafb7e4149ea7", [
      [ "none", "class_a_hdr.html#acfacae70f76a15f200eaafb7e4149ea7a334c4a4c42fdb79d7ebc3e73b517e6f8", null ],
      [ "rle", "class_a_hdr.html#acfacae70f76a15f200eaafb7e4149ea7a5e0ba941a9750318bd93522568476ad8", null ],
      [ "byterun", "class_a_hdr.html#acfacae70f76a15f200eaafb7e4149ea7affd951648f806ddbee00f8541c4a07df", null ],
      [ "rle3", "class_a_hdr.html#acfacae70f76a15f200eaafb7e4149ea7a6e5162b66413d7e4ffc68d94903f7ea0", null ],
      [ "byterun3", "class_a_hdr.html#acfacae70f76a15f200eaafb7e4149ea7a59c053e1a1d4ca6b23a3123c46f20e4f", null ]
    ] ],
    [ "AColor", "class_a_hdr.html#a7905be4154d0d5ccdbd7b4e0e4a59383", [
      [ "b_w", "class_a_hdr.html#a7905be4154d0d5ccdbd7b4e0e4a59383a73a128f1fb102f2c510a69c64d275ddf", null ],
      [ "grey", "class_a_hdr.html#a7905be4154d0d5ccdbd7b4e0e4a59383aca50000a180a293de0b27acb67a695cb", null ],
      [ "rgb", "class_a_hdr.html#a7905be4154d0d5ccdbd7b4e0e4a59383aef70a6546536ccd835479f6cddc0188e", null ],
      [ "rgba", "class_a_hdr.html#a7905be4154d0d5ccdbd7b4e0e4a59383a7082a31b8759c9d59795876351ec63aa", null ]
    ] ],
    [ "AHdr", "class_a_hdr.html#ae0e5c1931a8e406dec80ad482a0fc876", null ],
    [ "deserialize_header", "class_a_hdr.html#ac7e0ac7fd6dc8fb8084ce0644d5bde7d", null ],
    [ "serialize_header", "class_a_hdr.html#aae5a53a4c25244003988916b78e4b8f4", null ],
    [ "size_of_elements", "class_a_hdr.html#a71a973b675bf06717d598a3456bb062e", null ]
];