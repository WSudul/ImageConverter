var class_seven_bit_comp =
[
    [ "SevenBitComp", "class_seven_bit_comp.html#a88537f3efcfb1ded41fa646135be60b9", null ],
    [ "~SevenBitComp", "class_seven_bit_comp.html#a61568c430e83443ecb2ef290e41d8f53", null ],
    [ "SevenBitComp", "class_seven_bit_comp.html#a88537f3efcfb1ded41fa646135be60b9", null ],
    [ "~SevenBitComp", "class_seven_bit_comp.html#a72f06ca96f6b735a9afddc4778777786", null ],
    [ "compress", "class_seven_bit_comp.html#a3709d6c5760e370598bb24a608090325", null ],
    [ "compress", "class_seven_bit_comp.html#a281ae171d41a94ead9ef41e47f39c161", null ],
    [ "decompress", "class_seven_bit_comp.html#a4c6eb1aa39afa3d12da46e7aa4c8c844", null ],
    [ "decompress", "class_seven_bit_comp.html#acc3684fdfeffe60d1fe346d7975a545c", null ],
    [ "compressedData", "class_seven_bit_comp.html#a8119c8bd361a8880d7ffed5fdc291322", null ]
];