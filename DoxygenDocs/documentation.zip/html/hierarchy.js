var hierarchy =
[
    [ "AHdr::AAJWHEADER", "struct_a_hdr_1_1_a_a_j_w_h_e_a_d_e_r.html", null ],
    [ "Vec_BMP::BITMAPFILEHEADER", "struct_vec___b_m_p_1_1_b_i_t_m_a_p_f_i_l_e_h_e_a_d_e_r.html", null ],
    [ "Vec_BMP::BITMAPINFOHEADER", "struct_vec___b_m_p_1_1_b_i_t_m_a_p_i_n_f_o_h_e_a_d_e_r.html", null ],
    [ "ByteRun_c", "class_byte_run__c.html", null ],
    [ "ImgBaseInfo", "class_img_base_info.html", null ],
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "Vec_BMP::RGBQUAD", "struct_vec___b_m_p_1_1_r_g_b_q_u_a_d.html", null ],
    [ "RLE_c", "class_r_l_e__c.html", null ],
    [ "Scale", "class_scale.html", null ],
    [ "Serialize", "class_serialize.html", [
      [ "AHdr", "class_a_hdr.html", null ]
    ] ],
    [ "SevenBitComp", "class_seven_bit_comp.html", null ],
    [ "SFML_Objects", "class_s_f_m_l___objects.html", [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "MainWindow::unsigned_pair", "struct_main_window_1_1unsigned__pair.html", null ],
    [ "ImgBaseInfo::unsigned_pair", "struct_img_base_info_1_1unsigned__pair.html", null ],
    [ "Vec_BMP", "class_vec___b_m_p.html", [
      [ "Vec_Extr", "class_vec___extr.html", null ]
    ] ]
];