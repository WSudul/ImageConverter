var struct_main_window_1_1unsigned__pair =
[
    [ "x", "struct_main_window_1_1unsigned__pair.html#ac040b111fc19192daf8e0b0d2e55cba9", null ],
    [ "y", "struct_main_window_1_1unsigned__pair.html#ad221617aaed612158d17b0fe1cd5f098", null ]
];