var class_vec___b_m_p =
[
    [ "BITMAPFILEHEADER", "struct_vec___b_m_p_1_1_b_i_t_m_a_p_f_i_l_e_h_e_a_d_e_r.html", "struct_vec___b_m_p_1_1_b_i_t_m_a_p_f_i_l_e_h_e_a_d_e_r" ],
    [ "BITMAPINFOHEADER", "struct_vec___b_m_p_1_1_b_i_t_m_a_p_i_n_f_o_h_e_a_d_e_r.html", "struct_vec___b_m_p_1_1_b_i_t_m_a_p_i_n_f_o_h_e_a_d_e_r" ],
    [ "RGBQUAD", "struct_vec___b_m_p_1_1_r_g_b_q_u_a_d.html", "struct_vec___b_m_p_1_1_r_g_b_q_u_a_d" ],
    [ "Vec_BMP", "class_vec___b_m_p.html#a227e50226a532bfd54e6d960b6072dcd", null ],
    [ "deserialize_header_file", "class_vec___b_m_p.html#ae23ef5d71b03a20434770fc918a3b489", null ],
    [ "deserialize_header_info", "class_vec___b_m_p.html#a27a5e5986f85516f8a046ba0daa07913", null ],
    [ "QSaveToBMP", "class_vec___b_m_p.html#a61e14c6159b9ca012568a853c8d4b11a", null ],
    [ "SaveToBMP", "class_vec___b_m_p.html#a2c22309653b524d473ef671ba4c1fd18", null ],
    [ "serialize_header_file", "class_vec___b_m_p.html#a574b49380069a1ef4e9ce87385a54144", null ],
    [ "serialize_header_info", "class_vec___b_m_p.html#aa50195e9591d65b5b7104199fb6e2171", null ],
    [ "size_of_elements_file", "class_vec___b_m_p.html#a08a8ab56855abbfd977858febac8ef27", null ],
    [ "size_of_elements_info", "class_vec___b_m_p.html#addb2d7cdeba20e70d873e72b0c11330f", null ],
    [ "operator<<", "class_vec___b_m_p.html#a17da6c1c2e594bf0ed0738fe9a04c0d9", null ],
    [ "operator<<", "class_vec___b_m_p.html#ab0ed3e61b0d9653ad1ec5b69331bcbae", null ],
    [ "operator<<", "class_vec___b_m_p.html#a24e55a7f2cf78babf9d0a2dacb7bf431", null ]
];