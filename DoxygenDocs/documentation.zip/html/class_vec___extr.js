var class_vec___extr =
[
    [ "color_mode", "class_vec___extr.html#a8d7151eccfe7802f8a7ee13858efd092", [
      [ "RGB", "class_vec___extr.html#a8d7151eccfe7802f8a7ee13858efd092a889574aebacda6bfd3e534e2b49b8028", null ],
      [ "GREYSCALE", "class_vec___extr.html#a8d7151eccfe7802f8a7ee13858efd092a68577b71e3dd6736f90f7726368600a0", null ],
      [ "GREYSCALE_AVG", "class_vec___extr.html#a8d7151eccfe7802f8a7ee13858efd092a4bae3663163819d5196b3201217486f6", null ],
      [ "B_W", "class_vec___extr.html#a8d7151eccfe7802f8a7ee13858efd092aa6098321da8717e3aee5484162bf5ed4", null ],
      [ "INV_RGB", "class_vec___extr.html#a8d7151eccfe7802f8a7ee13858efd092a02bcf57989bdbf5da90ef5dd5bbcac10", null ],
      [ "RGBA", "class_vec___extr.html#a8d7151eccfe7802f8a7ee13858efd092aea3495a278957dc58165e48a8945469f", null ]
    ] ],
    [ "Vec_Extr", "class_vec___extr.html#a5a08e3bcfc30fdf31b48111571d3f5d6", null ],
    [ "~Vec_Extr", "class_vec___extr.html#acc0e0b163873786ec7a30bf73c55e506", null ],
    [ "extract", "class_vec___extr.html#ad92b6521264618ee65846c5578d82a00", null ],
    [ "img_extract", "class_vec___extr.html#a43e84d2878b1699d9016521b65e9f520", null ],
    [ "img_extract", "class_vec___extr.html#ad794de22e48f50b897a3f238cd583944", null ],
    [ "PackVectorTo32Bit", "class_vec___extr.html#ab3db59adefb7cdbdb005190898338c34", null ]
];