var struct_a_hdr_1_1_a_a_j_w_h_e_a_d_e_r =
[
    [ "F7Bit", "struct_a_hdr_1_1_a_a_j_w_h_e_a_d_e_r.html#a6e93e00502c01c65f0f8ce1ac20ec658", null ],
    [ "FColor", "struct_a_hdr_1_1_a_a_j_w_h_e_a_d_e_r.html#a14e5aedd0dc604584a3dcdc28cc96953", null ],
    [ "FCompression", "struct_a_hdr_1_1_a_a_j_w_h_e_a_d_e_r.html#aac95d8b273ca637de37d09365a8d7531", null ],
    [ "FDataSize", "struct_a_hdr_1_1_a_a_j_w_h_e_a_d_e_r.html#a8788fcefb6cf691306449590b598a8a1", null ],
    [ "FIdentifier", "struct_a_hdr_1_1_a_a_j_w_h_e_a_d_e_r.html#a66d5e7dee1661f0f9160208e7a86fec6", null ],
    [ "FSizeX", "struct_a_hdr_1_1_a_a_j_w_h_e_a_d_e_r.html#a4ed548bb0e52d953eda50ad44b1d62b8", null ],
    [ "FSizeY", "struct_a_hdr_1_1_a_a_j_w_h_e_a_d_e_r.html#ab5e34a0b2fc4be0287b8934d5d0515a7", null ]
];