var struct_vec___b_m_p_1_1_b_i_t_m_a_p_f_i_l_e_h_e_a_d_e_r =
[
    [ "bfOffBits", "struct_vec___b_m_p_1_1_b_i_t_m_a_p_f_i_l_e_h_e_a_d_e_r.html#afd21e073e3f62ae07bbf89d09433e4d1", null ],
    [ "bfReserved1", "struct_vec___b_m_p_1_1_b_i_t_m_a_p_f_i_l_e_h_e_a_d_e_r.html#a1d4bc29b7613f67993f60390072bd140", null ],
    [ "bfReserved2", "struct_vec___b_m_p_1_1_b_i_t_m_a_p_f_i_l_e_h_e_a_d_e_r.html#a27c955750faf54d41ce74f1838cfac17", null ],
    [ "bfSize", "struct_vec___b_m_p_1_1_b_i_t_m_a_p_f_i_l_e_h_e_a_d_e_r.html#a2413d5ece07b7d0d7c8de2f51f9853f9", null ],
    [ "bfType", "struct_vec___b_m_p_1_1_b_i_t_m_a_p_f_i_l_e_h_e_a_d_e_r.html#a9bb15d708b120cfa53ffdbc45c9f17cb", null ]
];